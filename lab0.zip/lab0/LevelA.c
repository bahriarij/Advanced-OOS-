#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>

#define MAX_BUFFER_SIZE 10
#define NUM_ITEMS 20

// تعريف بنية المخزن
typedef struct {
    int buffer[MAX_BUFFER_SIZE];
    int in;
    int out;
} shared_data;

// دالة لإجراء العمليات على semaphores
void P(int semid) {
    struct sembuf sb = {0, -1, 0};  // decrement semaphore
    semop(semid, &sb, 1);
}

void V(int semid) {
    struct sembuf sb = {0, 1, 0};  // increment semaphore
    semop(semid, &sb, 1);
}

// المنتج
void producer(shared_data *shm_data, int semid) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        P(semid);  // الانتظار إذا كان المخزن ممتلئًا
        shm_data->buffer[shm_data->in] = i;  // إضافة منتج إلى المخزن
        printf("منتج: العنصر %d أضيف في الموضع %d\n", i, shm_data->in);
        shm_data->in = (shm_data->in + 1) % MAX_BUFFER_SIZE;
        V(semid);  // الإشارة على أنه تم إضافة عنصر
        sleep(1);
    }
}

// المستهلك
void consumer(shared_data *shm_data, int semid) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        P(semid);  // الانتظار إذا كان المخزن فارغًا
        int item = shm_data->buffer[shm_data->out];  // أخذ عنصر من المخزن
        printf("مستهلك: العنصر %d تم استهلاكه من الموضع %d\n", item, shm_data->out);
        shm_data->out = (shm_data->out + 1) % MAX_BUFFER_SIZE;
        V(semid);  // الإشارة على أنه تم استهلاك عنصر
        sleep(1);
    }
}

int main() {
    // إنشاء shared memory
    int shm_id = shmget(IPC_PRIVATE, sizeof(shared_data), IPC_CREAT | 0666);
    if (shm_id < 0) {
        perror("shmget");
        exit(1);
    }

    shared_data *shm_data = (shared_data *)shmat(shm_id, NULL, 0);
    if (shm_data == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    // تهيئة المخزن
    shm_data->in = 0;
    shm_data->out = 0;

    // إنشاء semaphore
    int semid = semget(IPC_PRIVATE, 1, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget");
        exit(1);
    }

    // تهيئة semaphore
    semctl(semid, 0, SETVAL, 1);  // قيمة أولية للـ semaphore

    // إنشاء عمليات المنتج والمستهلك
    if (fork() == 0) {
        consumer(shm_data, semid);  // العملية الفرعية: المستهلك
        exit(0);
    } else {
        producer(shm_data, semid);  // العملية الرئيسية: المنتج
        wait(NULL);  // انتظار انتهاء العملية الفرعية
    }

    // تنظيف الموارد
    shmdt(shm_data);
    shmctl(shm_id, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    return 0;
}
