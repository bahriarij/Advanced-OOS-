#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/types.h>

#define MAX_BUFFER_SIZE 10
#define NUM_ITEMS 20
#define NUM_PRODUCERS 3
#define NUM_CONSUMERS 3

typedef struct {
    int buffer[MAX_BUFFER_SIZE];
    int in;
    int out;
} shared_data;

void P(int semid) {
    struct sembuf sb = {0, -1, 0};
    semop(semid, &sb, 1);
}

void V(int semid) {
    struct sembuf sb = {0, 1, 0};
    semop(semid, &sb, 1);
}

void producer(shared_data *shm_data, int semid, int producer_id) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        P(semid);
        shm_data->buffer[shm_data->in] = i + producer_id * NUM_ITEMS;
        printf("منتج %d: العنصر %d أضيف في الموضع %d\n", producer_id, i + producer_id * NUM_ITEMS, shm_data->in);
        shm_data->in = (shm_data->in + 1) % MAX_BUFFER_SIZE;
        V(semid);
        sleep(1);
    }
}

void consumer(shared_data *shm_data, int semid, int consumer_id) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        P(semid);
        int item = shm_data->buffer[shm_data->out];
        printf("مستهلك %d: العنصر %d تم استهلاكه من الموضع %d\n", consumer_id, item, shm_data->out);
        shm_data->out = (shm_data->out + 1) % MAX_BUFFER_SIZE;
        V(semid);
        sleep(1);
    }
}

int main() {
    int shm_id = shmget(IPC_PRIVATE, sizeof(shared_data), IPC_CREAT | 0666);
    if (shm_id < 0) {
        perror("shmget");
        exit(1);
    }

    shared_data *shm_data = (shared_data *)shmat(shm_id, NULL, 0);
    if (shm_data == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    shm_data->in = 0;
    shm_data->out = 0;

    int semid = semget(IPC_PRIVATE, 1, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget");
        exit(1);
    }
    semctl(semid, 0, SETVAL, 1);

    for (int i = 0; i < NUM_PRODUCERS; i++) {
        if (fork() == 0) {
            producer(shm_data, semid, i);
            exit(0);
        }
    }

    for (int i = 0; i < NUM_CONSUMERS; i++) {
        if (fork() == 0) {
            consumer(shm_data, semid, i);
            exit(0);
        }
    }

    for (int i = 0; i < NUM_PRODUCERS + NUM_CONSUMERS; i++) {
        wait(NULL);
    }

    shmdt(shm_data);
    shmctl(shm_id, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    return 0;
}

